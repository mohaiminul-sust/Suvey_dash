<?php 
	return array(
		'siteName'	=>	'surveyadmin'
	);
?>